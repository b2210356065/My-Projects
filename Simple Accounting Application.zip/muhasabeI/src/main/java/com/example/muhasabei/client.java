package com.example.muhasabei;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;

public class client {
    private HashMap<String,IncomeExpenses> monthly_income_expenses=new HashMap<>();
    private HashMap<String,IncomeExpenses> long_time_income_expenses=new HashMap<>();
    private LocalDate current_time=LocalDate.now();

    client(){
    }



    HashMap<String,IncomeExpenses> getMonthly_income_expenses() {
        return monthly_income_expenses;
    }
    HashMap<String,IncomeExpenses> getLong_time_income_expenses() {
        return long_time_income_expenses;
    }

    void add_income_expense(String Description,double amount, double interest,LocalDate start_date, LocalDate finish_date,boolean f){
        IncomeExpenses incomeExpenses=new IncomeExpenses(amount, interest, start_date, finish_date,f);//new amount object

        long months_for_expiry = ChronoUnit.MONTHS.between(start_date, finish_date);//examine for long or short time amount

        if(months_for_expiry>1){
            long_time_income_expenses.put(Description,incomeExpenses);
        }else {
            monthly_income_expenses.put(Description,incomeExpenses);
        }
    }

    void erase_amount(String key){
        if(monthly_income_expenses.containsKey(key)){
            monthly_income_expenses.remove(key);
        }else if(long_time_income_expenses.containsKey(key)){
            long_time_income_expenses.remove(key);
        }else {
            //error
        }
    }

    void ahead_a_day(LocalDate New){

        if(current_time.isBefore(New)){
            this.current_time=New;
        }


        for (String key : monthly_income_expenses.keySet()) {

            IncomeExpenses incomeExpenses=monthly_income_expenses.get(key);

            if(current_time.equals(incomeExpenses.getFinish_date())){
                if(incomeExpenses.is_mantain()){
                    incomeExpenses.setStart_date(incomeExpenses.getFinish_date());
                    incomeExpenses.setFinish_date(incomeExpenses.getFinish_date().plusMonths(1));
                    continue;
                }
                this.monthly_income_expenses.remove(key);
                incomeExpenses=null;//no more usage
            }
        }
        for (String key: long_time_income_expenses.keySet()) {
            IncomeExpenses incomeExpenses=long_time_income_expenses.get(key);
            double k=incomeExpenses.control_monthly_amount(New);
            if(k!=0){
                LocalDate finish = incomeExpenses.getStart_date().plusMonths(1);

                IncomeExpenses incomeExpenses_monthly=new IncomeExpenses(k,incomeExpenses.getInterest()*100
                        , incomeExpenses.getStart_date(), finish,false);

                monthly_income_expenses.put(key+"-monthly",incomeExpenses_monthly);
            }

            long months_for_expiry = ChronoUnit.MONTHS.between(incomeExpenses.getStart_date(),incomeExpenses.getFinish_date());

            if(months_for_expiry==0){
                this.long_time_income_expenses.remove(key);
                incomeExpenses=null;
            }

        }
    }
}
