package com.example.muhasabei;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {
    private clients_files clientsFiles;

    public void setClientsFiles(clients_files clientsFiles) {
        this.clientsFiles = clientsFiles;
    }

    @FXML
    private TextField inputField;

    @FXML
    private void handleCreateNewFile(ActionEvent event) {
        String userInput = inputField.getText();
        clientsFiles.create_new_client(userInput);
        switchScene(event, "open_file_view.fxml");
    }

    @FXML
    private void handleOpenFile(ActionEvent event) {
        switchScene(event, "open_file_view.fxml");
    }

    private void switchScene(ActionEvent event, String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            if (fxml.equals("open_file_view.fxml")) {
                OpenFileController openFileController = loader.getController();
                openFileController.setClientsFiles(clientsFiles);
                openFileController.populateFileList();
            }

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.close();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
