package com.example.muhasabei;

import com.example.muhasabei.MainController;
import com.example.muhasabei.clients_files;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URISyntaxException;

public class Main extends Application {
    static clients_files clientsFiles;


    @Override
    public void start(Stage stage) throws IOException, URISyntaxException {
        clientsFiles = new clients_files();
        clientsFiles.start_app();

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        fxmlLoader.setControllerFactory(param -> {
            MainController controller = new MainController();
            controller.setClientsFiles(clientsFiles);
            return controller;
        });

        Scene scene = new Scene(fxmlLoader.load(), 1920, 960);
        stage.setTitle("Accounting Application");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        if (clientsFiles != null) {
            clientsFiles.finish_app();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
