package com.example.muhasabei;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class OpenFileController {
    private clients_files clientsFiles;

    @FXML
    private VBox buttonContainer;
    @FXML
    private TextField inputField;

    public void setClientsFiles(clients_files clientsFiles) {
        this.clientsFiles = clientsFiles;
        populateFileList();
    }

    public void populateFileList() {
        buttonContainer.getChildren().clear(); // Önceki butonları temizle
        ArrayList<String> fileList = new ArrayList<>();
        for (String key : clientsFiles.getClients().keySet()) {
            fileList.add(key);
        }

        for (String fileName : fileList) {
            Button button = new Button(fileName);
            button.setOnAction(event -> handleFileButtonClick(fileName));
            buttonContainer.getChildren().add(button);
        }
    }

    private void handleFileButtonClick(String fileName) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("project.fxml"));
            Parent root = loader.load();

            ProjectController controller = loader.getController();
            controller.setClientsFiles(clientsFiles, fileName);

            Stage stage = (Stage) buttonContainer.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Failed to load Project View");
            alert.setContentText("An error occurred while loading the project view.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleRemoveFile() {
        String description = inputField.getText();

        if (description.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("No Description Provided");
            alert.setContentText("Please provide a description to delete.");
            alert.showAndWait();
            return;
        }

        if (clientsFiles != null && clientsFiles.getClients().containsKey(description)) {
            clientsFiles.getClients().remove(description);
            populateFileList();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Client Not Found");
            alert.setContentText("Client with name '" + description + "' does not exist.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleAddFile() {
        String description = inputField.getText();

        if (description.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("No Description Provided");
            alert.setContentText("Please provide a description to add.");
            alert.showAndWait();
            return;
        }

        if (clientsFiles != null && !clientsFiles.getClients().containsKey(description)) {
            clientsFiles.create_new_client(description);
            populateFileList();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Client Already Exists");
            alert.setContentText("Client with name '" + description + "' already exists.");
            alert.showAndWait();
        }
    }
}



