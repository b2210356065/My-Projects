package com.example.muhasabei;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Map;

public class ProjectController {
    @FXML
    private TextField descriptionField;
    @FXML
    private TextField EraseField;
    @FXML
    private TextField amountField;
    @FXML
    private TextField interestField;
    @FXML
    private TextField startDateField;
    @FXML
    private TextField finishDateField;
    @FXML
    private CheckBox isLongTermCheckBox;
    @FXML
    private TextArea monthlyIncomeExpensesArea;
    @FXML
    private TextArea longTimeIncomeExpensesArea;
    @FXML
    private Label timeLabel;

    private clients_files clientsFiles;
    private String name;
    private Timeline timeline;
    private LocalDate currentTime;

    public void setClientsFiles(clients_files clientsFiles, String name) {
        this.clientsFiles = clientsFiles;
        this.name = name;
        this.currentTime = LocalDate.now(); // Başlangıç zamanı ayarla

        // Zamanlayıcıyı başlat
        startTimeline();
        updateIncomeExpenseAreas();
    }
    @FXML
    private void handleProject(ActionEvent event) {
        switchScene(event, "open_file_view.fxml");
    }

    private void switchScene(ActionEvent event, String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            if (fxml.equals("open_file_view.fxml")) {
                OpenFileController openFileController = loader.getController();
                openFileController.setClientsFiles(clientsFiles);
                openFileController.populateFileList();
            }

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.close();

            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleAddIncomeExpense() {
        String description = descriptionField.getText();
        double amount;
        double interest;
        LocalDate startDate;
        LocalDate finishDate;
        boolean isLongTerm;

        try {
            amount = Double.parseDouble(amountField.getText());
            interest = Double.parseDouble(interestField.getText());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            startDate = LocalDate.parse(startDateField.getText(), formatter);
            finishDate = LocalDate.parse(finishDateField.getText(), formatter);
            isLongTerm = isLongTermCheckBox.isSelected();

            if (clientsFiles != null && clientsFiles.getClients().containsKey(name)) {
                clientsFiles.getClients().get(name).add_income_expense(description, amount, interest, startDate, finishDate, isLongTerm);
                updateIncomeExpenseAreas();
            } else {
                throw new NullPointerException("clientsFiles or client not found.");
            }
        } catch (NumberFormatException | DateTimeParseException | NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("Invalid input detected");
            alert.setContentText("Please ensure all fields are correctly filled and client exists.");
            alert.showAndWait();
        }
    }


    @FXML
    public void initialize() {
        startTimeline();
    }

    private void startTimeline() {


        Duration oneMonthDuration = Duration.hours(24);


        timeline = new Timeline(new KeyFrame(oneMonthDuration, event -> {
            if (clientsFiles != null && clientsFiles.getClients().containsKey(name)) {
                currentTime = currentTime.plusDays(1);
                clientsFiles.getClients().get(name).ahead_a_day(currentTime);
                timeLabel.setText("At " + currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                updateIncomeExpenseAreas();
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

    }
    @FXML
    private void handleEraseIncomeExpense() {
        String description = EraseField.getText();

        if (description.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("No Description Provided");
            alert.setContentText("Please provide a description to delete.");
            alert.showAndWait();
            return;
        }

        if (clientsFiles != null && clientsFiles.getClients().containsKey(name)) {
            clientsFiles.getClients().get(name).erase_amount(description);
            updateIncomeExpenseAreas();
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Client Not Found");
            alert.setContentText("Client with name '" + name + "' does not exist.");
            alert.showAndWait();
        }
    }
    private void updateIncomeExpenseAreas() {
        StringBuilder monthlyBuilder = new StringBuilder();
        StringBuilder longTimeBuilder = new StringBuilder();
        double sum=0;
        if (clientsFiles != null && clientsFiles.getClients().containsKey(name)) {
            for (Map.Entry<String, IncomeExpenses> entry : clientsFiles.getClients().get(name).getMonthly_income_expenses().entrySet()) {
                IncomeExpenses incomeExpenses = entry.getValue();
                if(ChronoUnit.MONTHS.between(currentTime,incomeExpenses.getStart_date())<=0){
                    sum+=incomeExpenses.getAmount();
                    monthlyBuilder.append("Description: ").append(entry.getKey())
                            .append("\tAmount: ").append(incomeExpenses.getAmount())
                            .append("\tInterest: ").append(incomeExpenses.getInterest())
                            .append("\tStart Date: ").append(incomeExpenses.getStart_date())
                            .append("\tFinish Date: ").append(incomeExpenses.getFinish_date())
                            .append("\t\n");
                }
            }
            monthlyBuilder.append("Monthly Profit: "+sum+"\n");

            for (Map.Entry<String, IncomeExpenses> entry : clientsFiles.getClients().get(name).getLong_time_income_expenses().entrySet()) {
                IncomeExpenses incomeExpenses = entry.getValue();
                if(ChronoUnit.MONTHS.between(currentTime,incomeExpenses.getStart_date())<=0){
                    longTimeBuilder.append("Description: ").append(entry.getKey())
                            .append("\tAmount: ").append(incomeExpenses.getAmount())
                            .append("\tInterest: ").append(incomeExpenses.getInterest())
                            .append("\tStart Date: ").append(incomeExpenses.getStart_date())
                            .append("\tFinish Date: ").append(incomeExpenses.getFinish_date())
                            .append("\t\n");
                }

            }
        } else {
            monthlyBuilder.append("Client not found.");
            longTimeBuilder.append("Client not found.");
        }

        monthlyIncomeExpensesArea.setText(monthlyBuilder.toString());
        longTimeIncomeExpensesArea.setText(longTimeBuilder.toString());
    }
}
