package com.example.muhasabei;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class clients_files {
    save_changes saveChanges=new save_changes();
    HashMap<String, client> clients=new HashMap<>();


    public clients_files() throws URISyntaxException {
    }
    HashMap<String, client> getClients() {
        return clients;
    }
    public void start_app(){
        clients=saveChanges.uploaddata();
    }
    public void finish_app(){
        saveChanges.savedata(clients);
    }
    public void create_new_client(String name){
        clients.put(name,new client());
    }
    public void erase_client(String name){
        clients.remove(name);
    }
}
