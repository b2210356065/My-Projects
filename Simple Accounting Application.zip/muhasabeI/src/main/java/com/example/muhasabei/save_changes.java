package com.example.muhasabei;

import java.io.*;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

public class save_changes {
    File currentDir;
    File txtFile;

    public save_changes() throws URISyntaxException {
        currentDir = new File(save_changes.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParentFile();
        txtFile = new File(currentDir, "data.dat");
    }
    HashMap<String,client> uploaddata(){
        System.out.println(txtFile);
        HashMap<String,client> clients_list = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(txtFile))) {
            String line;
            client client = new client();
            while ((line = reader.readLine()) != null) {

                String datas[]=line.split("\t");

                if(datas[0].equals("-----")){

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    String key=datas[1];
                    double maint=Double.parseDouble(datas[2]);
                    double interest=Double.parseDouble(datas[3]);
                    LocalDate start_date = LocalDate.parse(datas[4], formatter);
                    LocalDate finish_date = LocalDate.parse(datas[5], formatter);
                    boolean i_m=Boolean.getBoolean(datas[6]);
                    client.add_income_expense(key,maint,interest,start_date,finish_date,i_m);

                }else{
                    clients_list.put(line,client);
                    client=new client();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return clients_list;
    }


    void savedata(HashMap<String,client> clients_list) {
        try (FileWriter writer = new FileWriter(txtFile)) {
            for (String k: clients_list.keySet()) {
                client client=clients_list.get(k);

                for (String key:client.getMonthly_income_expenses().keySet()){

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    IncomeExpenses incomeExpenses=client.getMonthly_income_expenses().get(key);

                    String start = incomeExpenses.getStart_date().format(formatter);
                    String finish= incomeExpenses.getFinish_date().format(formatter);
                    String i_m;

                    if(incomeExpenses.is_mantain()){
                        i_m="1";
                    }else{
                        i_m="0";
                    }

                    writer.write("-----"+"\t"+key+"\t"+incomeExpenses.getAmount()+"\t"+incomeExpenses.getInterest()+"\t"+start+"\t"+finish+"\t"+i_m+"\n");
                }
                for(String key: client.getLong_time_income_expenses().keySet()){

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    IncomeExpenses incomeExpenses=client.getLong_time_income_expenses().get(key);

                    String start = incomeExpenses.getStart_date().format(formatter);
                    String finish= incomeExpenses.getFinish_date().format(formatter);
                    String i_m;

                    if(incomeExpenses.is_mantain()){
                        i_m="1";
                    }else{
                        i_m="0";
                    }

                    writer.write("-----"+"\t"+key+"\t"+incomeExpenses.getAmount()+"\t"+incomeExpenses.getInterest()+"\t"+start+"\t"+finish+"\t"+i_m+"\n");
                }
                writer.write(k+"\n");

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
