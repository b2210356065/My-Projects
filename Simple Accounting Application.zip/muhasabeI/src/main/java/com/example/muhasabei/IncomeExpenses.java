package com.example.muhasabei;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class IncomeExpenses {
    private double amount;
    private double interest;
    private LocalDate start_date;
    private LocalDate finish_date;
    private boolean is_mantain;
    IncomeExpenses(double amount, double interest,LocalDate start_date,LocalDate finish_date,boolean is_mantain) {
        this.amount = amount;
        this.interest = interest/100;
        this.start_date = start_date;
        this.finish_date = finish_date;
        this.is_mantain = is_mantain;
    }

    double getAmount(){
        return amount;
    }
    LocalDate getFinish_date() {
        return finish_date;
    }
    LocalDate getStart_date() {
        return start_date;
    }
    double getInterest() {
        return interest;
    }
    boolean is_mantain() {
        return is_mantain;
    }
    void setAmount(double amount) {
        this.amount += amount;
    }
    void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }
    void setFinish_date(LocalDate finish_date) {
        this.finish_date = finish_date;
    }



    double control_monthly_amount(LocalDate current_time) {
        long monthsBetween = ChronoUnit.MONTHS.between(start_date, current_time);
        if (monthsBetween >= 1) {
            this.amount=amount*(1+interest/12);//new amount with interest

            this.start_date = current_time;

            long months = ChronoUnit.MONTHS.between(current_time,finish_date);

            double monthly_amount=amount/months;

            this.amount-=monthly_amount;

            return monthly_amount;
        }
        return 0;
    }
}
