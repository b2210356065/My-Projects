#include <iostream>
#include <vector>
#include <iomanip>
#include "math.h"

using namespace std;

struct sample{
    double value[2][2];
    void assign(double x,double y,double z,double t){
        value[0][0]=x;
        value[0][1]=y;
        value[1][0]=z;
        value[1][1]=t;
    }
};

struct node{
    double value=0;
    vector<double>weightlist;
    vector<node*> next_edgelist;
    vector<node*> prev_edgelist;

};
node* create_graph_for_ai(){
    //create graph from ending
    node *n=new node;//end node1
    n->prev_edgelist.push_back(new node);//nodes from prev level
    n->prev_edgelist.push_back(new node);
    node *k=new node;//end node2
    k->prev_edgelist.push_back(n->prev_edgelist[0]);
    k->prev_edgelist.push_back(n->prev_edgelist[1]);
    //assign next edges
    n->prev_edgelist[0]->next_edgelist.push_back(n);
    n->prev_edgelist[0]->next_edgelist.push_back(k);
    n->prev_edgelist[1]->next_edgelist.push_back(n);
    n->prev_edgelist[1]->next_edgelist.push_back(k);
    //reduce level
    n=n->prev_edgelist[0];
    k=k->prev_edgelist[1];
    //create head
    node *head=new node;
    head->value=0;
    //constitute beginning level
    node *a=new node;
    head->next_edgelist.push_back(a);
    n->prev_edgelist.push_back(a);
    k->prev_edgelist.push_back(a);
    a->next_edgelist.push_back(n);
    a->next_edgelist.push_back(k);
    a=new node;
    head->next_edgelist.push_back(a);
    n->prev_edgelist.push_back(a);
    k->prev_edgelist.push_back(a);
    a->next_edgelist.push_back(n);
    a->next_edgelist.push_back(k);
    a=new node;
    head->next_edgelist.push_back(a);
    n->prev_edgelist.push_back(a);
    k->prev_edgelist.push_back(a);
    a->next_edgelist.push_back(n);
    a->next_edgelist.push_back(k);
    a=new node;
    head->next_edgelist.push_back(a);
    n->prev_edgelist.push_back(a);
    k->prev_edgelist.push_back(a);
    a->next_edgelist.push_back(n);
    a->next_edgelist.push_back(k);
    return head;
}
void assign_weights(node *head){
    int a=0;
    while (!head->next_edgelist.empty()){
        for (int i = 0; i < head->next_edgelist.size(); ++i) {
            node *curr=head->next_edgelist[i];
            if(a>=1){
                if(i%2==0){
                    curr->weightlist.push_back(0.5);
                    curr->weightlist.push_back(0);
                }else{
                    curr->weightlist.push_back(0);
                    curr->weightlist.push_back(0.5);
                }
            }else{
                if(i%2==0){
                    curr->weightlist.push_back(0.6);
                    curr->weightlist.push_back(-0.4);
                }else{
                    curr->weightlist.push_back(-0.8);
                    curr->weightlist.push_back(0.6);
                }
            }
        }
        a++;
        head=head->next_edgelist[0];
    }
}

void clear_graph(node *head){
    while (!head->next_edgelist.empty()){
        for (node *k:head->next_edgelist) {
            k->value=0;
        }
        head=head->next_edgelist[0];
    }
}

void train_ai(node *head,vector<sample*>&list_of_samples){
    int gradient_parameter=list_of_samples.size();
    node *temp=head;
    for (int f = 0; f < 60000; ++f) {
        for (sample *c:list_of_samples) {
            head=temp;
            head->next_edgelist[0]->value=c->value[0][0];
            head->next_edgelist[1]->value=c->value[0][1];
            head->next_edgelist[2]->value=c->value[1][0];
            head->next_edgelist[3]->value=c->value[1][1];
            int k=0;
            while (k<2) {
                double sum_sqr=0;
                for (int i = 0; i < head->next_edgelist.size(); ++i) {
                    head->next_edgelist[i]->next_edgelist[0]->value+=head->next_edgelist[i]->value*head->next_edgelist[i]->weightlist[0];

                    head->next_edgelist[i]->next_edgelist[1]->value+=head->next_edgelist[i]->value*head->next_edgelist[i]->weightlist[1];

                    sum_sqr+=head->next_edgelist[i]->value*head->next_edgelist[i]->value;


                }
                sum_sqr= sqrt(sum_sqr);

                double cost_change=0;
                for (int i = 0; i < head->next_edgelist.size(); ++i) {
                    for (int j = 0; j < 2; ++j) {
                        cost_change+= head->next_edgelist[i]->value/(sum_sqr*gradient_parameter*1000);
                        if(k%2==1){
                            head->next_edgelist[i]->weightlist[j] -= head->next_edgelist[i]->value/(sum_sqr*gradient_parameter*1000);
                            continue;
                        }
                        if (i % 2 == 0 && j % 2 == 0) {
                            head->next_edgelist[i]->weightlist[j] += head->next_edgelist[i]->value/(sum_sqr*gradient_parameter*1000);
                        }
                        else if (i % 2 != 0 && j % 2 != 0) {
                            head->next_edgelist[i]->weightlist[j] += head->next_edgelist[i]->value/(sum_sqr*gradient_parameter*1000);
                        }
                    }
                }
                k++;
                head=head->next_edgelist[0];
            }
        }
        clear_graph(temp);
    }
}

void is_colomn(node *head,sample* c){
    clear_graph(head);
    head->next_edgelist[0]->value=c->value[0][0];
    head->next_edgelist[1]->value=c->value[0][1];
    head->next_edgelist[2]->value=c->value[1][0];
    head->next_edgelist[3]->value=c->value[1][1];
    int k=0;
    while (!head->next_edgelist.empty()){
        for (int i = 0; i < head->next_edgelist.size(); ++i) {
            if(k<2){
                head->next_edgelist[i]->next_edgelist[0]->value+=head->next_edgelist[i]->value*head->next_edgelist[i]->weightlist[0];
                head->next_edgelist[i]->next_edgelist[1]->value+=head->next_edgelist[i]->value*head->next_edgelist[i]->weightlist[1];
            }

        }
        k++;
        head=head->next_edgelist[0];
    }
    double cost1=(1-head->value)*(1-head->value)+(head->prev_edgelist[0]->next_edgelist[1]->value)*(head->prev_edgelist[0]->next_edgelist[1]->value);
    double cost2=(head->value)*(head->value)+(1-head->prev_edgelist[0]->next_edgelist[1]->value)*(1-head->prev_edgelist[0]->next_edgelist[1]->value);
    if(cost1<cost2){
        cout<<"true";
    }else if(cost2<cost1){
        cout<<"false";
    }else{
        cout<<"equal";
    }
}

int main() {
    node *head=create_graph_for_ai();
    assign_weights(head);

    //train with basic data set
    vector<sample*> list_of_samples;
    sample *sa=new sample;
    sa->assign(0.7,0.7,0.7,0.7);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.5,0,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.5,0,0.5);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.8,0.5,0,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0,0.7,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.5,0.6,0.7);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.9,0,0.8);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0,0.3,0.5);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.5,0,0,0.6);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.5,0,0,0.5);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.5,0,0.6,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.8,0,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.5,0.5,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.2,0.2,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.5,0,0.7,0.2);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0,0.2,0);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0.5,0,0.8);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0,0,0,0.5);
    list_of_samples.push_back(sa);
    sa=new sample;
    sa->assign(0.3,0,0,0);
    list_of_samples.push_back(sa);

    train_ai(head,list_of_samples);

    sa=new sample;

    sa->assign(0.9,0.8,0.6,0);
    is_colomn(head,sa);
    //destructor
    delete sa;
    for (sample *c: list_of_samples) {
        delete c;
    }
    while (!head->next_edgelist.empty()){
        node *temp=head;
        for (int i = 1; i < head->next_edgelist.size(); ++i) {
            delete head->next_edgelist[i];
        }
        head=head->next_edgelist[0];
        delete temp;
    }
    delete head;
    return 0;
}
