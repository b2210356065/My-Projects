//
// Created by Lenovo on 28.06.2024.
//

#ifndef UNTITLED7_SHAPES_H
#define UNTITLED7_SHAPES_H


class shapes {
public:
    int all_shapes[9][9][9];
    shapes();
};


#endif //UNTITLED7_SHAPES_H
